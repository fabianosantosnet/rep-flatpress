<?php
/*
Plugin Name: DateChanger Alternative
Version: 1.0
Plugin URI: https://wiki.flatpress.org/res:plugins:datechangeralternative
Description: Lets you change creation date/time only for new entries<br><br><small>Supported languages: portuguese, spanish, japanese, italian and english.</small>
Author: @fabianosantosnet
Author URI: https://fabianosantosnet.github.io/FlatPressCMS/

Old version info Plugin Name: DateChanger alternate for Da capo
Old version info Version: 0.9
Old version info Plugin URI: https://nhws.localinfo.jp/
Old version info Description: Lets you change creation date/time for new entries.
Old version info Author: ぴー＠西東京
Old version info Author URI: https://nhws.localinfo.jp/

#modified by @fabianosantosnet 11/26/2022 - added pt_br lang and added some html markup
*/ 

if (! (
	basename($_SERVER['PHP_SELF']) == 'admin.php'	&&	// must be admin area
	@$_GET['p'] == 'entry' 				&&	// must be right panel
	@$_GET['action'] == 'write'			&&	// must be right action    
	!(@$_POST['timestamp'] || @$_REQUEST['entry'])	// must be a new entry
	) ) 
		return;

function plugin_datechangeralternative_toolbar() {
	
	$lang = lang_load('plugin:datechangeralternative');	// 多言語対応
	$time = date_time();
	
	$h = date('H', $time);
	$m = date('i', $time);
	$s = date('s', $time);
	
	$Y = date('Y', $time);
	$M = date('m', $time);
	$D = date('d', $time);
	
	echo '<link rel="stylesheet" type="text/css" href="'.plugin_geturl('datechangeralternative') . 'res/calendar.css" />', "\n";
	echo '<script type="text/javascript" src="'.plugin_geturl('datechangeralternative') . 'res/calendar.js"></script>', "\n";
    
    #include(CONFIG_FILE);
    #print $fp_config['locale']['dateformatshort']
    #$fdate=str_replace('%','',($fp_config['locale']['dateformatshort']));
	#$datafshort= date($fdate);

	echo '<span id="admin-date">';
	echo '<b>DateChanger Plugin</b>';
	echo ' '. $lang['plugin']['datechangeralternative']['date'].' ';
	#echo '<input type="text" value="'.$datafshort.'" size="12" readonly name="pubDate" onclick="displayCalendar(document.forms[0].pubDate,\''.$datafshort.'\',this)" />';    
    echo '<input type="text" value="'.$Y.'/'.$M.'/'.$D.'" size="12" readonly name="pubDate" onclick="displayCalendar(document.forms[0].pubDate,\'yyyy/mm/dd\',this)" />';
    
	echo ' '. $lang['plugin']['datechangeralternative']['time'].' ';
	echo '<input type="text" name="pubTime" value="'.$h.':'.$m.':'.$s.'" id="pubTime" onblur=\'timeCheck(document.getElementById("pubTime"))\' maxlength="8" size="10"/>';
    echo '<br><small><span>'.$lang['plugin']['datechangeralternative']['info'].'</span></small>';    
	echo '</span>';
}

add_action('editor_toolbar', 'plugin_datechangeralternative_toolbar');

function plugin_datechangeralternative_check() {
	
	if ((isset($_GET['p']) && $_GET['p'] != 'entry') || 
		(isset($_GET['action']) &&  $_GET['action'] != 'write')) return;
	
	if (empty($_POST)) return;
	
	// Retreiving post date
	if (!empty($_POST['pubDate']))
		$date = $_REQUEST['pubDate'];
	else 
		return;
	
	// Retreiving post time
	if (!empty($_POST['pubTime']))
		$time = $_REQUEST['pubTime'];
	else 
		return;
	
	$dsep = "/";
	$d = explode($dsep, $date);
	
	$tsep = ":";
	$t = explode($tsep, $time);
	
	$time = mktime ( $t[0], $t[1], $t[2], $d[1], $d[2], $d[0] );
	
	$_POST['timestamp'] = $time;
}

add_action('init', 'plugin_datechangeralternative_check');

function timeCheck() {
	echo '<script type="text/javascript" src="'.plugin_geturl('datechangeralternative') . 'res/time.js"></script>', "\n";	
}

add_action('wp_head', 'timeCheck');

?>