resディレクトリー内のcalendar.jsファイルの53行目を使用するlanguageCodeに書き換えてください(初期値はjp)

Change to your languageCode at the file calendar.js line 53 in directory res.(default is jp)

===
Added language pt br - modified by @fabianosantosnet changed in november/2022

Name DateChanger Alternative
Current version 1.0

