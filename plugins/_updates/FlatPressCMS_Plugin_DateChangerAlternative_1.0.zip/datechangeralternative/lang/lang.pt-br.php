<?php

	$lang['plugin']['datechangeralternative'] = array(		
		'date'		=> 'Data da publicação:',
		'time'		=> 'Hora:',
        'info'      => 'Crie a postagem com uma data específica'
	);
?>