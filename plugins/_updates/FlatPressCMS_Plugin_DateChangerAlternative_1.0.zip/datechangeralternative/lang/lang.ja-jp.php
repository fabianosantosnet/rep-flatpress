<?php

	$lang['plugin']['datechangeralternative'] = array(
		
		'date'		=> '投稿日:',
		'time'		=> '投稿時刻:',
        'info'      => '特定の日付で投稿を作成する'
	);
?>