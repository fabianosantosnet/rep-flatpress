<?php

	$lang['plugin']['datechangeralternative'] = array(
		
		'date'		=> 'Publish date:',
		'time'		=> 'Time:',
        'info'      => 'Create the post with a specific date'
	);
?>