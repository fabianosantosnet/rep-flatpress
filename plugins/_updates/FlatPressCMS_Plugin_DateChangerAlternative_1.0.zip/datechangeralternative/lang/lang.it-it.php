<?php

	$lang['plugin']['datechangeralternative'] = array(
		
		'date'		=> 'Data pubblicazione:',
		'time'		=> 'Ora pubblicazione:',
        'info'      => 'Crea il post con una data specifica'
	);
?>