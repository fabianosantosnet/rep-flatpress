<?php

	$lang['plugin']['datechangeralternative'] = array(		
		'date'		=> 'Fecha de publicación:',
		'time'		=> 'Hora:',
        'info'      => 'Crear la publicación con una fecha específica'
        );
?>