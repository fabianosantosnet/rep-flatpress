<?php
/*  
Style Name: jacutinga
Style URI: http://git.fabianosantos.net
Description: Dark blue, light blue, black and white theme
Version: 1
Author: fabianosantosnet
Author URI: http://git.fabianosantos.net
*/
	
	$style['name'] = 'jacutinga';
	$style['author'] = 'fabianosantosnet';
	$style['www'] = 'http://git.fabianosantos.net';
	
	$style['version'] = 1.0;
		
	$style['style_def'] = 'style.css';
	$style['style_admin'] = 'admin_j.css';
	#$style['style_print'] = 'print.css';
	$style['style'] = 'default';
	
?>
