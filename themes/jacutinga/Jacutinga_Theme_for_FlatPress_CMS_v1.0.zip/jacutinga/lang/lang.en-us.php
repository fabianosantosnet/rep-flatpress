<?php

$lang['themes']['jacutinga'] = array (
	'category' => 'Category',
    'no_category'=>'Uncategorized',
    'tag'=>'Tag',
    'archive'=>'Archive'
);

?>
