<?php

$lang['themes']['jacutinga'] = array (
	'category' => 'Categoria',
    'no_category'=>'Não categorizado',
    'tag'=>'Tag',
    'archive'=>'Arquivos'
);

?>
