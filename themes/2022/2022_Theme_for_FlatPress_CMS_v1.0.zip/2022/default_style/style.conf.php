<?php
/*  
Style Name: 2022
Style URI: http://git.fabianosantos.net
Description: Clean white, black and gray theme
Version: 1
Author: @fabianosantosnet
Author URI: http://git.fabianosantos.net
*/
	
	$style['name'] = '2022';
	$style['author'] = '@fabianosantosnet';
	$style['www'] = 'http://git.fabianosantos.net';
	
	$style['version'] = 1.0;
		
	$style['style_def'] = 'style.css';
	$style['style_admin'] = 'admin.css';
	$style['style_print'] = 'print.css';
	$style['style'] = 'default';
	
?>
