<?php
/*
 * Theme Name: 2022
 * Theme URI: http://git.fabianosantos.net/
 * Description: First clean FlatPress Theme based on Leggero v2
 * Version: 0.705
 * Author: @fabianosantosnet
 * Author URI: http://git.fabianosantos.net/
 */
$theme ['name'] = '2022';
$theme ['author'] = 'fabianosantosnet';
$theme ['www'] = 'http://git.fabianosantos.net/';
$theme ['description'] = 'First clean FlatPress Theme based on Leggero v2.';

$theme ['version'] = 0.705;

$theme ['style_def'] = 'style.css';
$theme ['style_admin'] = 'admin.css';

$theme ['default_style'] = 'default_style';

// Other theme settings

// overrides default tabmenu
// and panel layout
remove_filter('admin_head', 'admin_head_action');

// register widgetsets
register_widgetset('top');
register_widgetset('right');
register_widgetset('left');

?>
